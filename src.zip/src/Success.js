import { useState } from "react";

import SuccessForm from "./SuccessForm";
import SuccessList from "./SuccessList";

function Success() {

    const [title, setTitle] = useState("");
    const [desc, setDesc] = useState("");
    const [editingId, setEditingId] = useState(null);

    return (
        <div className="success-page">

            <SuccessForm
                title={title}
                setTitle={setTitle}
                desc={desc}
                setDesc={setDesc}
                editingId={editingId}
                setEditingId={setEditingId}
            />

            <SuccessList
                setTitle={setTitle}
                setDesc={setDesc}
                setEditingId={setEditingId}
            />

        </div>
    );
}
export default Success;